import streamlit as st
import joblib
import numpy as np
import base64


def add_bg_from_local(image_file):
    with open(image_file, "rb") as img_file:
        encoded = base64.b64encode(img_file.read()).decode()
    st.markdown(
        f"""
        <style>
        .stApp {{
            background-image: url("data:image/jpg;base64,{encoded}");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

# Set background
add_bg_from_local(r"C:\Users\user\DATA SCIENCE\ML PROJECT\Two Wheeler .jpg")

# Load model & encoder
model = joblib.load(r"C:\Users\user\DATA SCIENCE\ML PROJECT\model.pkl")
le = joblib.load(r"C:\Users\user\DATA SCIENCE\ML PROJECT\le.pkl")

st.title("Two Wheeler Brand Prediction")

# Input fields
Type = st.number_input("Type: (0=Bike, 1=Scooter)")
Rating = st.number_input("Rating :(1 to 4) ")
Review_Type = st.number_input("Review Type:[ Positive(1) or Negative(0) ]")
Range_km = st.number_input("Km Range")
Usage_Type = st.number_input("Usage_Type: Bussiness use ,Delivery ,Personal ,Daily use(0 to 3)")
Service_Rating = st.number_input("Service_Rating (1 to 5)")
Warranty_Years = st.number_input("Warranty_Years (2 or 3)")

if st.button("Predict"):
    input_data = np.array([[Type,Rating,Review_Type,Range_km,Usage_Type,Service_Rating,Warranty_Years]])

    prediction = model.predict(input_data)
    decoded = le.inverse_transform(prediction)
    st.success(f"Predicted Best Brand: {decoded[0]}")